package pe.edu.trujidelivery.pe.edu.trujidelivery.modelo

data class Negocio(
    var id: String = "",
    var nombre: String = "",
    var imagenUrl: String = "",
    var categoriaId: String = ""
)
