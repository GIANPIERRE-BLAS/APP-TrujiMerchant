package pe.edu.trujidelivery.modelo

data class Producto(
    var id: String = "",
    val nombre: String = "",
    val descripcion: String = "",
    val precio: Double = 0.0,
    val imagenUrl: String = "",
    var cantidad: Int = 0,
    var descuento: Int? = null
){
    // Calcular precio con descuento
    fun precioConDescuento(): Double {
        return if (descuento != null && descuento!! > 0) {
            precio * (1 - descuento!! / 100.0)
        } else {
            precio
        }
    }
}