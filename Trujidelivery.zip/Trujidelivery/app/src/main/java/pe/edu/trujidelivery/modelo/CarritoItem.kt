package pe.edu.trujidelivery.modelo


data class CarritoItem(
    val id: String = "",
    val nombre: String = "",
    val precio: Double = 0.0,
    val imagenUrl: String = "",
    var cantidad: Int = 1,
    val negocioNombre: String = "",
    val negocioId: String  = "",
    val categoriaId: String  = "",
    val imagenNegocio: String = "",
) {
    fun calcularTotal(): Double = precio * cantidad
}
