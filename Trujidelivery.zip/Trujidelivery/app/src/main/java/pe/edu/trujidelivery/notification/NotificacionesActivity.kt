package pe.edu.trujidelivery.notification

import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import pe.edu.trujidelivery.R
import pe.edu.trujidelivery.pe.edu.trujidelivery.adapters.NotificacionesAdapter
import pe.edu.trujidelivery.pe.edu.trujidelivery.modelo.Notificacion

class NotificacionesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var noNotificationsText: TextView
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val notificaciones = mutableListOf<Notificacion>()
    private lateinit var notificacionesAdapter: NotificacionesAdapter
    private val NOTIFICATION_CHANNEL_ID = "delivery_tracking"
    private val NOTIFICATION_ID_BASE = 2000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notificaciones)
        supportActionBar?.hide()

        recyclerView = findViewById(R.id.recyclerViewNotificaciones)
        progressBar = findViewById(R.id.progressBar)
        noNotificationsText = findViewById(R.id.noNotificationsText)

        // Enviar notificaciones locales no leídas al iniciar
        enviarNotificacionesNoLeidas()

        setupRecyclerView()
        cargarNotificaciones()
    }

    private fun enviarNotificacionesNoLeidas() {
        val usuarioId = auth.currentUser?.uid ?: return
        db.collection("notificaciones")
            .whereEqualTo("usuario_id", usuarioId)
            .whereEqualTo("leida", false)
            .get()
            .addOnSuccessListener { snapshot ->
                for (doc in snapshot.documents) {
                    val titulo = doc.getString("titulo") ?: "Notificación"
                    val mensaje = doc.getString("mensaje") ?: "Tienes un nuevo mensaje"
                    val notificationId = NOTIFICATION_ID_BASE + doc.id.hashCode()

                    enviarNotificacionLocal(titulo, mensaje, notificationId)

                    // Marcar como leída después de enviar la notificación
                    doc.reference.update("leida", true)
                        .addOnSuccessListener {
                            cargarNotificaciones() // Recargar la lista para reflejar el cambio
                        }
                }
            }
            .addOnFailureListener { e ->
                Log.e("NotificacionesActivity", "Error al cargar notificaciones no leídas: ${e.message}")
            }
    }

    private fun enviarNotificacionLocal(title: String, message: String, notificationId: Int) {
        val intent = Intent(this, NotificacionesActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_delivery_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI)
            .setVibrate(longArrayOf(0, 500, 200, 500))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = NotificationManagerCompat.from(this)
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            notificationManager.notify(notificationId, notification)
        }
    }

    private fun setupRecyclerView() {
        notificacionesAdapter = NotificacionesAdapter(notificaciones) { notificacion ->
            db.collection("notificaciones")
                .document(notificacion.id)
                .update("leida", true)
                .addOnSuccessListener {
                    notificacionesAdapter.notifyDataSetChanged()
                }
        }
        recyclerView.apply {
            layoutManager = LinearLayoutManager(this@NotificacionesActivity)
            adapter = notificacionesAdapter
        }
    }

    private fun cargarNotificaciones() {
        val usuarioId = auth.currentUser?.uid ?: return
        progressBar.visibility = View.VISIBLE
        noNotificationsText.visibility = View.GONE

        db.collection("notificaciones")
            .whereEqualTo("usuario_id", usuarioId)
            .orderBy("fecha_hora", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { snapshot ->
                notificaciones.clear()
                for (doc in snapshot.documents) {
                    val notificacion = Notificacion(
                        id = doc.id,
                        usuarioId = doc.getString("usuario_id") ?: "",
                        titulo = doc.getString("titulo") ?: "",
                        mensaje = doc.getString("mensaje") ?: "",
                        fechaHora = doc.getString("fecha_hora") ?: "",
                        pedidoId = doc.getString("pedido_id"),
                        leida = doc.getBoolean("leida") ?: false
                    )
                    notificaciones.add(notificacion)
                }
                notificacionesAdapter.notifyDataSetChanged()
                progressBar.visibility = View.GONE
                noNotificationsText.visibility = if (notificaciones.isEmpty()) View.VISIBLE else View.GONE
            }
            .addOnFailureListener { e ->
                progressBar.visibility = View.GONE
                noNotificationsText.visibility = View.VISIBLE
                noNotificationsText.text = "Error al cargar notificaciones: ${e.message}"
            }
    }
}